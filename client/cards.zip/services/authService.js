const checkToken = async(_url) => {
  // קודם בודק בכלל שהטוקן קיים
  if(!localStorage["tok"]){
   return window.location.href = "login.html"
  }
  // let url = "http://localhost:3000/users/userInfo";
  

  // console.log(data);

}