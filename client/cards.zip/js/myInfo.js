$(() => {
  init();
})

const init = () => {
  checkToken("http://localhost:3000/users/userInfo");
}