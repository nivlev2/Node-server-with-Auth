$(() => {
  init();
})

const init = () => {
  $("#id_form").on("submit", (evt) => {

    evt.preventDefault();
    let bodyData = {
      email: $("#id_email").val(),
      password: $("#id_pass").val()
    }
    tryLogIn(bodyData)

    console.log(bodyData);
  })
}

const tryLogIn = async (bodyData) => {
  let url = "http://localhost:3000/users/login";
  let data = await doApiMethod(url,"POST",bodyData);
  // let resp = await fetch(url, {
  //   method: "POST",
  //   body: JSON.stringify(bodyData),
  //   headers: {
  //     'content-type': "application/json"
  //   }
  // })
  // let data = await resp.json();
  if(data.token){
    // שמירה של הטוקן בלוקאל
    localStorage.setItem("tok",data.token)
  }
  else{
    alert("User name or password worng!");
  }
  console.log(data);
}